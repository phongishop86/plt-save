// PLT Save – chạy trong trang Facebook (MAIN world)
// Đọc HTML ban đầu + các phản hồi GraphQL/AJAX mà Facebook tải thêm khi lướt (Reels, bảng tin),
// lấy video kèm tên kênh rồi gửi sang extension qua postMessage.
(function () {
  if (window.__pltHooked) return;
  window.__pltHooked = true;
  const parse = window.__pltParseFB;
  if (!parse) return;

  const send = items => {
    if (items && items.length) window.postMessage({ __plt: "fbItems", items }, location.origin);
  };
  const handle = txt => {
    try {
      if (typeof txt === "string" && txt.length > 200 && txt.indexOf("fbcdn") >= 0 &&
          /browser_native|playable_url|progressive_url/.test(txt)) send(parse(txt));
    } catch (e) { /* bỏ qua */ }
  };
  const wanted = u => /\/api\/graphql|\/ajax\/|\/graphql/.test(String(u || ""));

  // XHR (Facebook dùng chủ yếu)
  const XO = XMLHttpRequest.prototype.open, XS = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__pltUrl = u; return XO.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function () {
    if (wanted(this.__pltUrl)) {
      this.addEventListener("load", () => {
        try { if (!this.responseType || this.responseType === "text") handle(this.responseText); } catch (e) {}
      });
    }
    return XS.apply(this, arguments);
  };

  // fetch
  const F = window.fetch;
  window.fetch = function (input, init) {
    const p = F.apply(this, arguments);
    const u = typeof input === "string" ? input : (input && input.url);
    if (wanted(u)) p.then(r => r.clone().text().then(handle).catch(() => {})).catch(() => {});
    return p;
  };

  // HTML ban đầu (dữ liệu nhúng trong <script>)
  const scanDoc = () => handle(document.documentElement.innerHTML);
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", scanDoc);
  else scanDoc();
  window.addEventListener("load", () => setTimeout(scanDoc, 1500));
})();
