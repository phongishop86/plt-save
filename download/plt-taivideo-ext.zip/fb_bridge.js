// PLT Save – cầu nối: nhận video từ trang (fb_hook.js) và chuyển cho extension
// Trang vừa tải lại thật -> xoá danh sách video cũ của tab
try { chrome.runtime.sendMessage({ type: "fbReset" }); } catch (err) {}
window.addEventListener("message", e => {
  if (e.source !== window || !e.data || e.data.__plt !== "fbItems") return;
  try { chrome.runtime.sendMessage({ type: "fbItems", items: e.data.items }); } catch (err) { /* extension vừa cập nhật */ }
});
