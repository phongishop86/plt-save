// PLT Tải Video - nền (service worker)
// Nhiệm vụ: "nghe" các yêu cầu mạng của từng tab, ghi lại link video/âm thanh.

const MAX_PER_TAB = 60;
const MEDIA_EXT = /\.(mp4|webm|m4a|m4v|mp3|aac|ogg|m3u8|mpd)(\?|$)/i;

function tabKey(tabId) { return "tab_" + tabId; }

// Chuẩn hoá link: bỏ tham số cắt đoạn để lấy nguyên file
function normalize(rawUrl) {
  let u;
  try { u = new URL(rawUrl); } catch { return null; }
  const host = u.hostname;
  if (host.includes("fbcdn.net")) {
    u.searchParams.delete("bytestart");
    u.searchParams.delete("byteend");
  }
  if (host.includes("googlevideo.com")) {
    ["range", "rn", "rbuf", "ump", "srfvp", "alr", "cpn", "cver"].forEach(p => u.searchParams.delete(p));
  }
  return u.toString();
}

function platformOf(url) {
  if (/fbcdn\.net|facebook\.com/.test(url)) return "facebook";
  if (/douyinvod|douyin|bytecdn|zjcdn|amemv/.test(url)) return "douyin";
  if (/googlevideo\.com/.test(url)) return "youtube";
  return "web";
}

function headerVal(headers, name) {
  const h = (headers || []).find(x => x.name.toLowerCase() === name);
  return h ? h.value : "";
}

async function addMedia(tabId, item) {
  const key = tabKey(tabId);
  const data = (await chrome.storage.session.get(key))[key] || [];
  const idx = data.findIndex(x => x.id === item.id);
  if (idx >= 0) {
    // cập nhật dung lượng nếu biết rõ hơn
    if (item.size && (!data[idx].size || item.size > data[idx].size)) data[idx].size = item.size;
    data[idx].t = Date.now();
  } else {
    data.push(item);
    if (data.length > MAX_PER_TAB) data.splice(0, data.length - MAX_PER_TAB);
  }
  await chrome.storage.session.set({ [key]: data });
  chrome.action.setBadgeText({ tabId, text: data.length ? String(data.length) : "" });
  chrome.action.setBadgeBackgroundColor({ tabId, color: "#F26B1D" });
}

chrome.webRequest.onHeadersReceived.addListener(
  (d) => {
    if (d.tabId < 0 || d.method !== "GET") return;
    const ctype = headerVal(d.responseHeaders, "content-type").toLowerCase();
    const isHls = /mpegurl/.test(ctype) || /\.m3u8(\?|$)/i.test(d.url);
    const isDash = /dash\+xml/.test(ctype) || /\.mpd(\?|$)/i.test(d.url);
    const isMedia = /^(video|audio)\//.test(ctype) || MEDIA_EXT.test(d.url) || /googlevideo\.com\/videoplayback/.test(d.url);
    if (!isMedia && !isHls && !isDash) return;
    if (/\.(ts|m4s)(\?|$)/i.test(d.url)) return; // mảnh nhỏ của luồng, bỏ qua

    const url = normalize(d.url);
    if (!url) return;
    const u = new URL(url);

    // tổng dung lượng: ưu tiên content-range "bytes 0-1/12345"
    let size = 0;
    const cr = headerVal(d.responseHeaders, "content-range");
    const m = cr.match(/\/(\d+)$/);
    if (m) size = +m[1];
    else size = +headerVal(d.responseHeaders, "content-length") || 0;
    const chunked = /fbcdn\.net|googlevideo\.com/.test(u.hostname); // link bị cắt đoạn: dung lượng chưa phải cả file
    if (u.searchParams.get("clen")) size = +u.searchParams.get("clen"); // YouTube ghi sẵn tổng dung lượng
    else if (chunked && !m) size = 0;
    if (!chunked && !isHls && !isDash && size && size < 60 * 1024) return; // quá nhỏ: quảng cáo, âm báo...

    let kind = "video";
    let mime = ctype || u.searchParams.get("mime") || "";
    if (isHls) kind = "hls";
    else if (isDash) kind = "dash";
    else if (/^audio\//.test(mime) || /audio/.test(decodeURIComponent(u.searchParams.get("mime") || ""))) kind = "audio";

    const platform = platformOf(url);
    // YouTube: định danh theo itag (mỗi itag = 1 chất lượng)
    let id = url.split("?")[0] + "|" + (u.searchParams.get("efg") || "");
    if (platform === "youtube") id = "yt_" + (u.searchParams.get("id") || "") + "_" + u.searchParams.get("itag");
    if (platform === "web" || platform === "douyin") id = url;

    addMedia(d.tabId, {
      id, url, kind, platform, size,
      mime: decodeURIComponent(mime),
      itag: u.searchParams.get("itag") || "",
      src: "net", t: Date.now()
    });
  },
  { urls: ["<all_urls>"], types: ["media", "xmlhttprequest", "other"] },
  ["responseHeaders"]
);

// Tab tải trang mới / tải lại thì xoá danh sách cũ
chrome.tabs.onUpdated.addListener(async (tabId, info) => {
  if (info.status === "loading") {
    await chrome.storage.session.remove(tabKey(tabId));
    chrome.action.setBadgeText({ tabId, text: "" });
  }
});
chrome.tabs.onRemoved.addListener(tabId => chrome.storage.session.remove(tabKey(tabId)));

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  (async () => {
    if (msg.type === "getMedia") {
      const key = tabKey(msg.tabId);
      reply((await chrome.storage.session.get(key))[key] || []);
    } else if (msg.type === "clear") {
      await chrome.storage.session.remove(tabKey(msg.tabId));
      chrome.action.setBadgeText({ tabId: msg.tabId, text: "" });
      reply(true);
    } else if (msg.type === "download") {
      try {
        const id = await chrome.downloads.download({ url: msg.url, filename: msg.filename, conflictAction: "uniquify" });
        reply({ ok: true, id });
      } catch (e) {
        reply({ ok: false, error: String(e.message || e) });
      }
    }
  })();
  return true;
});
