// PLT Save - popup
const $ = s => document.querySelector(s);
const ITAG = { // YouTube: itag -> chất lượng
  18: "360p (có tiếng)", 22: "720p (có tiếng)",
  160: "144p", 133: "240p", 134: "360p", 135: "480p", 136: "720p", 137: "1080p", 298: "720p60", 299: "1080p60",
  264: "1440p", 266: "2160p", 278: "144p", 242: "240p", 243: "360p", 244: "480p", 247: "720p", 248: "1080p",
  302: "720p60", 303: "1080p60", 271: "1440p", 313: "2160p",
  394: "144p", 395: "240p", 396: "360p", 397: "480p", 398: "720p", 399: "1080p", 400: "1440p", 401: "2160p",
  139: "48k", 140: "128k", 141: "256k", 249: "50k", 250: "70k", 251: "160k"
};
const AUDIO_ITAGS = new Set([139, 140, 141, 249, 250, 251]);

let tab, pageInfo = { title: "", items: [], fb: [], playing: null }, netItems = [], fbItems = [];

const fmtSize = b => !b ? "" : b > 1073741824 ? (b / 1073741824).toFixed(2) + " GB" : (b / 1048576).toFixed(1) + " MB";
const safeName = s => (s || "video").replace(/[\\/:*?"<>|\n\r\t~]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 60) || "video";
const fmtDur = s => !s ? "" : `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, "0")}`;
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// ===== Hàm chạy BÊN TRONG trang web để tìm video =====
async function scanPage() {
  const out = [];
  const seen = new Set();
  const add = (url, label, platform) => {
    if (!url || url.startsWith("blob:") || seen.has(url)) return;
    if (url.startsWith("//")) url = location.protocol + url;
    seen.add(url);
    out.push({ url, label, platform, kind: "av", src: "page" });
  };
  const unjson = s => { try { return JSON.parse('"' + s + '"'); } catch { return null; } };
  const host = location.hostname;
  const title = (document.querySelector('meta[property="og:title"]')?.content || document.title || "")
    .replace(/\s*\|\s*Facebook$/, "").replace(/\s*-\s*YouTube$/, "").trim();

  let fb = [];
  const isFB = /(^|\.)facebook\.com$/.test(host);
  if (isFB && window.__pltParseFB) {
    fb = window.__pltParseFB(document.documentElement.innerHTML);
    if (!fb.length) { // trang chuyển kiểu SPA: tải lại HTML của link hiện tại
      try { fb = window.__pltParseFB(await (await fetch(location.href, { credentials: "include" })).text()); } catch {}
    }
  }

  // Video đang phát (để đánh dấu "Đang xem"): ưu tiên video đang chạy, không thì video to nhất trên màn hình
  let playing = null, bestArea = 0;
  document.querySelectorAll("video").forEach(v => {
    const r = v.getBoundingClientRect();
    const vis = Math.max(0, Math.min(r.bottom, innerHeight) - Math.max(r.top, 0)) * Math.max(0, Math.min(r.right, innerWidth) - Math.max(r.left, 0));
    const score = vis + (!v.paused && v.currentTime > 0 ? 1e9 : 0);
    if (score > bestArea && isFinite(v.duration) && v.duration > 0) { bestArea = score; playing = { dur: v.duration }; }
  });

  // Thẻ <video> thật trên trang (Douyin, web khác)
  if (!isFB) document.querySelectorAll("video, video source").forEach(v => {
    const s = v.currentSrc || v.src || v.getAttribute("src");
    const plat = /douyin/.test(host) ? "douyin" : /facebook/.test(host) ? "facebook" : "web";
    if (s && !s.startsWith("blob:")) add(s, "Video trên trang (có tiếng)", plat);
  });

  return { title, host, url: location.href, items: out, fb, playing };
}

// ===== Hiển thị =====
function row(it, best) {
  const d = document.createElement("div");
  d.className = "it" + (best ? " best" : "");
  const name = it.fname || ("plt-save_" + safeName(pageInfo.title) + "." + it.ext); // tên file mang thương hiệu
  d.innerHTML = `
    <div class="info">
      <b><span class="tag t-${it.platform}">${{facebook:"FB",douyin:"抖音",youtube:"YT",web:"WEB"}[it.platform] || "WEB"}</span>${it.label}</b>
      <small>${[it.ext.toUpperCase(), fmtSize(it.size), it.note].filter(Boolean).join(" · ")}</small>
    </div>`;
  if (it.kind === "hls" || it.kind === "dash") {
    const c = btn("Copy link", "cp", async () => { await navigator.clipboard.writeText(it.url); c.textContent = "Đã copy ✓"; });
    d.append(c);
  } else {
    d.append(btn("Tải về", "dl", () => download(it.url, name, d)));
  }
  return d;
}
function btn(text, cls, fn) { const b = document.createElement("button"); b.className = "btn " + cls; b.textContent = text; b.onclick = fn; return b; }

async function download(url, filename, el, b) {
  const r = await chrome.runtime.sendMessage({ type: "download", url, filename });
  b = b || el.querySelector(".dl");
  if (r?.ok) { b.textContent = "Đang tải ✓"; }
  else { chrome.tabs.create({ url }); b.textContent = "Mở tab"; } // dự phòng: mở link để lưu thủ công
}

// ===== Facebook: mỗi video 1 thẻ, ghi rõ TÊN KÊNH =====
function fbCard(v, isNow) {
  const d = document.createElement("div");
  d.className = "fb" + (isNow ? " now" : "");
  const owner = v.owner || "Không rõ kênh";
  const shortId = String(v.id).slice(-6);
  const base = "plt-save_" + safeName(v.owner || pageInfo.title) + "_" + shortId;
  d.innerHTML = `
    <div class="fb-top">
      <span class="tag t-facebook">FB</span><b class="owner" title="${esc(owner)}">👤 ${esc(owner)}</b>
      ${isNow ? '<span class="now-badge">▶ Đang xem</span>' : ""}
    </div>
    <small class="cap">${[v.dur ? "⏱ " + fmtDur(v.dur) : "", v.cap ? esc(v.cap) : ""].filter(Boolean).join(" · ") || "Mã video: " + esc(v.id)}</small>
    <div class="fb-act"></div>`;
  const act = d.querySelector(".fb-act");
  if (v.hd) { const b = btn("⬇ HD", "dl", () => download(v.hd, base + ".mp4", d, b)); act.append(b); }
  if (v.sd) { const b = btn(v.hd ? "SD" : "⬇ SD", v.hd ? "cp" : "dl", () => download(v.sd, base + (v.hd ? "_SD" : "") + ".mp4", d, b)); act.append(b); }
  const fn = document.createElement("small"); fn.className = "fname"; fn.textContent = base + ".mp4"; act.append(fn);
  return d;
}

function render() {
  const list = $("#list");
  list.innerHTML = "";
  $("#page").textContent = pageInfo.title || tab.url;

  // 1) Video có tiếng tìm thấy trong trang (ưu tiên)
  const best = pageInfo.items.map(x => ({ ...x, ext: "mp4", qual: x.label.split(" ")[0] }));
  // 2) Luồng bắt được qua mạng
  const net = netItems.map(x => {
    const itag = +x.itag;
    let label, qual, note = "";
    const ext = x.kind === "hls" ? "m3u8" : x.kind === "dash" ? "mpd"
      : /webm/.test(x.mime) ? (x.kind === "audio" ? "webm" : "webm") : x.kind === "audio" ? "m4a" : "mp4";
    if (x.platform === "youtube" && itag) {
      const isA = AUDIO_ITAGS.has(itag) || x.kind === "audio";
      qual = ITAG[itag] || "itag" + itag;
      label = isA ? `Âm thanh ${qual}` : `Video ${qual}` + (itag === 18 || itag === 22 ? "" : " (không tiếng)");
      x.kind = isA ? "audio" : x.kind;
    } else if (x.kind === "hls") { label = "Luồng HLS (m3u8)"; note = "dùng với IDM / VLC"; }
    else if (x.kind === "dash") { label = "Luồng DASH (mpd)"; note = "dùng với IDM / VLC"; }
    else if (x.kind === "audio") label = "Âm thanh";
    else label = x.platform === "facebook" ? "Video (có thể không tiếng)" : "Video";
    return { ...x, label, qual: qual || label.split(" ")[1] || "video", ext, note };
  });
  net.sort((a, b) => (b.size || 0) - (a.size || 0));

  // Facebook: danh sách theo kênh
  if (fbItems.length) {
    const pd = pageInfo.playing?.dur;
    const isNow = v => pd && v.dur && Math.abs(v.dur - pd) <= 1.5;
    const sorted = [...fbItems].sort((a, b) => (isNow(b) - isNow(a)) || ((b.t || 0) - (a.t || 0))).slice(0, 25);
    list.insertAdjacentHTML("beforeend", `<div class="grp">🎬 Video Facebook trên trang (${fbItems.length}) – có tiếng</div>`);
    sorted.forEach(v => list.append(fbCard(v, isNow(v))));
    if (net.length) {
      const det = document.createElement("details");
      det.className = "more";
      det.innerHTML = `<summary>📡 Luồng mạng khác (${net.length}) – nâng cao, thường không tiếng</summary>`;
      net.forEach(it => det.append(row(it, false)));
      list.append(det);
    }
  }

  if (!fbItems.length && best.length) {
    list.insertAdjacentHTML("beforeend", `<div class="grp">✅ Khuyên dùng – video có tiếng</div>`);
    best.forEach((it, i) => list.append(row(it, i === 0)));
  }
  if (!fbItems.length && net.length) {
    list.insertAdjacentHTML("beforeend", `<div class="grp">📡 Luồng bắt được khi phát video</div>`);
    net.forEach(it => list.append(row(it, false)));
  }
  if (!fbItems.length && !best.length && !net.length) {
    list.innerHTML = `<div class="empty">Chưa thấy video nào.<br><b>Bấm phát video</b> vài giây rồi bấm nút ⟳ phía trên.<br>Facebook: mở riêng video (bấm vào video để xem toàn màn hình) sẽ dễ bắt hơn.</div>`;
  }

  const notes = [];
  if (/youtube\.com/.test(tab.url)) notes.push("YouTube tách hình và tiếng thành 2 file. Một số video YouTube được bảo vệ nên không bắt được luồng.");
  if (/facebook\.com/.test(tab.url) && fbItems.length) notes.push("Tên file = tên kênh + mã video. Video đang phát được đánh dấu ▶ Đang xem và xếp đầu. Lướt thêm rồi bấm ⟳ để cập nhật.");
  else if (/facebook\.com/.test(tab.url) && net.length) notes.push("Facebook: chưa đọc được dữ liệu video. Tải lại trang (F5) rồi phát video, bấm ⟳.");
  $("#note").style.display = notes.length ? "block" : "none";
  $("#note").textContent = notes.join(" ");
}

async function load() {
  const forced = +new URLSearchParams(location.search).get("tabId"); // dùng khi kiểm thử
  [tab] = forced ? [await chrome.tabs.get(forced)] : await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https?:/.test(tab.url || "")) {
    $("#list").innerHTML = `<div class="empty">Mở một trang web có video (Facebook, Douyin, YouTube...) rồi bấm lại biểu tượng PLT.</div>`;
    return;
  }
  netItems = await chrome.runtime.sendMessage({ type: "getMedia", tabId: tab.id }) || [];
  fbItems = await chrome.runtime.sendMessage({ type: "getFB", tabId: tab.id }) || [];
  try {
    if (/facebook\.com/.test(tab.url)) await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["fb_parse.js"] });
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: scanPage });
    if (r?.result) pageInfo = r.result;
  } catch { pageInfo = { title: tab.title, items: [] }; }
  if (!pageInfo.title) pageInfo.title = tab.title;
  // gộp video FB từ trang (quét lúc mở popup) với danh sách đã bắt khi lướt
  for (const v of pageInfo.fb || []) {
    const old = fbItems.find(x => x.id === v.id);
    if (old) { for (const f of ["owner", "dur", "cap", "hd", "sd"]) if (!old[f] && v[f]) old[f] = v[f]; }
    else fbItems.push({ ...v, t: 0 });
  }
  render();
}

$("#refresh").onclick = () => { $("#list").innerHTML = `<div class="empty">Đang quét...</div>`; load(); };
load();
