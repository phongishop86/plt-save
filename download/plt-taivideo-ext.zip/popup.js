// PLT Tải Video - popup
const $ = s => document.querySelector(s);
const ITAG = { // YouTube: itag -> chất lượng
  18: "360p (có tiếng)", 22: "720p (có tiếng)",
  160: "144p", 133: "240p", 134: "360p", 135: "480p", 136: "720p", 137: "1080p", 298: "720p60", 299: "1080p60",
  264: "1440p", 266: "2160p", 278: "144p", 242: "240p", 243: "360p", 244: "480p", 247: "720p", 248: "1080p",
  302: "720p60", 303: "1080p60", 271: "1440p", 313: "2160p",
  394: "144p", 395: "240p", 396: "360p", 397: "480p", 398: "720p", 399: "1080p", 400: "1440p", 401: "2160p",
  139: "48k", 140: "128k", 141: "256k", 249: "50k", 250: "70k", 251: "160k"
};
const AUDIO_ITAGS = new Set([139, 140, 141, 249, 250, 251]);

let tab, pageInfo = { title: "", items: [] }, netItems = [];

const fmtSize = b => !b ? "" : b > 1073741824 ? (b / 1073741824).toFixed(2) + " GB" : (b / 1048576).toFixed(1) + " MB";
const safeName = s => (s || "video").replace(/[\\/:*?"<>|\n\r\t]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 80) || "video";

// ===== Hàm chạy BÊN TRONG trang web để tìm video =====
async function scanPage() {
  const out = [];
  const seen = new Set();
  const add = (url, label, platform) => {
    if (!url || url.startsWith("blob:") || seen.has(url)) return;
    if (url.startsWith("//")) url = location.protocol + url;
    seen.add(url);
    out.push({ url, label, platform, kind: "av", src: "page" });
  };
  const unjson = s => { try { return JSON.parse('"' + s + '"'); } catch { return null; } };
  const host = location.hostname;
  const title = (document.querySelector('meta[property="og:title"]')?.content || document.title || "")
    .replace(/\s*\|\s*Facebook$/, "").replace(/\s*-\s*YouTube$/, "").trim();

  if (/facebook\.com$/.test(host) || host.endsWith(".facebook.com")) {
    const parse = (txt) => {
      const pats = [
        [/"browser_native_hd_url":"([^"]+)"/g, "HD (có tiếng)"],
        [/"playable_url_quality_hd":"([^"]+)"/g, "HD (có tiếng)"],
        [/"progressive_url":"([^"]+)","failure_reason":null,"metadata":\{"quality":"HD"/g, "HD (có tiếng)"],
        [/"browser_native_sd_url":"([^"]+)"/g, "SD (có tiếng)"],
        [/"playable_url":"([^"]+)"/g, "SD (có tiếng)"],
        [/"progressive_url":"([^"]+)","failure_reason":null,"metadata":\{"quality":"SD"/g, "SD (có tiếng)"]
      ];
      for (const [re, label] of pats) {
        let m; while ((m = re.exec(txt)) && out.length < 12) add(unjson(m[1]), label, "facebook");
      }
    };
    parse(document.documentElement.innerHTML);
    if (!out.length) { // trang chuyển kiểu SPA: tải lại HTML của link hiện tại
      try { parse(await (await fetch(location.href, { credentials: "include" })).text()); } catch {}
    }
  }

  // Thẻ <video> thật trên trang (Douyin, web khác)
  document.querySelectorAll("video, video source").forEach(v => {
    const s = v.currentSrc || v.src || v.getAttribute("src");
    const plat = /douyin/.test(host) ? "douyin" : /facebook/.test(host) ? "facebook" : "web";
    if (s && !s.startsWith("blob:")) add(s, "Video trên trang (có tiếng)", plat);
  });

  return { title, host, url: location.href, items: out };
}

// ===== Hiển thị =====
function row(it, best) {
  const d = document.createElement("div");
  d.className = "it" + (best ? " best" : "");
  const name = safeName(pageInfo.title) + "_" + (it.qual || "video").replace(/[()\s]+/g, "") + "." + it.ext;
  d.innerHTML = `
    <div class="info">
      <b><span class="tag t-${it.platform}">${{facebook:"FB",douyin:"抖音",youtube:"YT",web:"WEB"}[it.platform] || "WEB"}</span>${it.label}</b>
      <small>${[it.ext.toUpperCase(), fmtSize(it.size), it.note].filter(Boolean).join(" · ")}</small>
    </div>`;
  if (it.kind === "hls" || it.kind === "dash") {
    const c = btn("Copy link", "cp", async () => { await navigator.clipboard.writeText(it.url); c.textContent = "Đã copy ✓"; });
    d.append(c);
  } else {
    d.append(btn("Tải về", "dl", () => download(it.url, name, d)));
  }
  return d;
}
function btn(text, cls, fn) { const b = document.createElement("button"); b.className = "btn " + cls; b.textContent = text; b.onclick = fn; return b; }

async function download(url, filename, el) {
  const r = await chrome.runtime.sendMessage({ type: "download", url, filename });
  const b = el.querySelector(".dl");
  if (r?.ok) { b.textContent = "Đang tải ✓"; }
  else { chrome.tabs.create({ url }); b.textContent = "Mở tab"; } // dự phòng: mở link để lưu thủ công
}

function render() {
  const list = $("#list");
  list.innerHTML = "";
  $("#page").textContent = pageInfo.title || tab.url;

  // 1) Video có tiếng tìm thấy trong trang (ưu tiên)
  const best = pageInfo.items.map(x => ({ ...x, ext: "mp4", qual: x.label.split(" ")[0] }));
  // 2) Luồng bắt được qua mạng
  const net = netItems.map(x => {
    const itag = +x.itag;
    let label, qual, note = "";
    const ext = x.kind === "hls" ? "m3u8" : x.kind === "dash" ? "mpd"
      : /webm/.test(x.mime) ? (x.kind === "audio" ? "webm" : "webm") : x.kind === "audio" ? "m4a" : "mp4";
    if (x.platform === "youtube" && itag) {
      const isA = AUDIO_ITAGS.has(itag) || x.kind === "audio";
      qual = ITAG[itag] || "itag" + itag;
      label = isA ? `Âm thanh ${qual}` : `Video ${qual}` + (itag === 18 || itag === 22 ? "" : " (không tiếng)");
      x.kind = isA ? "audio" : x.kind;
    } else if (x.kind === "hls") { label = "Luồng HLS (m3u8)"; note = "dùng với IDM / VLC"; }
    else if (x.kind === "dash") { label = "Luồng DASH (mpd)"; note = "dùng với IDM / VLC"; }
    else if (x.kind === "audio") label = "Âm thanh";
    else label = x.platform === "facebook" ? "Video (có thể không tiếng)" : "Video";
    return { ...x, label, qual: qual || label.split(" ")[1] || "video", ext, note };
  });
  net.sort((a, b) => (b.size || 0) - (a.size || 0));

  if (best.length) {
    list.insertAdjacentHTML("beforeend", `<div class="grp">✅ Khuyên dùng – video có tiếng</div>`);
    best.forEach((it, i) => list.append(row(it, i === 0)));
  }
  if (net.length) {
    list.insertAdjacentHTML("beforeend", `<div class="grp">📡 Luồng bắt được khi phát video</div>`);
    net.forEach(it => list.append(row(it, false)));
  }
  if (!best.length && !net.length) {
    list.innerHTML = `<div class="empty">Chưa thấy video nào.<br><b>Bấm phát video</b> vài giây rồi bấm nút ⟳ phía trên.<br>Facebook: mở riêng video (bấm vào video để xem toàn màn hình) sẽ dễ bắt hơn.</div>`;
  }

  const notes = [];
  if (/youtube\.com/.test(tab.url)) notes.push("YouTube tách hình và tiếng thành 2 file. Một số video YouTube được bảo vệ nên không bắt được luồng.");
  if (/facebook\.com/.test(tab.url) && !best.length && net.length) notes.push("Facebook: luồng bắt qua mạng thường tách hình/tiếng. Mở riêng video rồi bấm ⟳ để lấy bản có tiếng.");
  $("#note").style.display = notes.length ? "block" : "none";
  $("#note").textContent = notes.join(" ");
}

async function load() {
  const forced = +new URLSearchParams(location.search).get("tabId"); // dùng khi kiểm thử
  [tab] = forced ? [await chrome.tabs.get(forced)] : await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https?:/.test(tab.url || "")) {
    $("#list").innerHTML = `<div class="empty">Mở một trang web có video (Facebook, Douyin, YouTube...) rồi bấm lại biểu tượng PLT.</div>`;
    return;
  }
  netItems = await chrome.runtime.sendMessage({ type: "getMedia", tabId: tab.id }) || [];
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: scanPage });
    if (r?.result) pageInfo = r.result;
  } catch { pageInfo = { title: tab.title, items: [] }; }
  if (!pageInfo.title) pageInfo.title = tab.title;
  render();
}

$("#refresh").onclick = () => { $("#list").innerHTML = `<div class="empty">Đang quét...</div>`; load(); };
load();
