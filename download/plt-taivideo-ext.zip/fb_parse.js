// PLT Save – bộ đọc dữ liệu video Facebook
// Tìm trong văn bản (HTML / phản hồi GraphQL) các link video CÓ TIẾNG (HD/SD) và gắn:
//   tên kênh (chủ video), mã video, thời lượng, chú thích ngắn.
(function () {
  const URL_RE = /"(browser_native_hd_url|browser_native_sd_url|playable_url_quality_hd|playable_url|progressive_url)":\s*"((?:[^"\\]|\\.)+)"/g;
  const OWNER_RES = [
    /"(?:owner|video_owner)":\{"__typename":"(?:User|Page)"[^{}]*?"name":"((?:[^"\\]|\\.)+)"/g,
    /"(?:owner|video_owner)":\{[^{}]*?"name":"((?:[^"\\]|\\.)+)"[^{}]*?"__typename":"(?:User|Page)"/g,
    /"actors":\[\{"__typename":"(?:User|Page)"[^{}]*?"name":"((?:[^"\\]|\\.)+)"/g,
  ];
  const ID_RES = [/"(?:videoId|video_id)":"(\d{6,})"/g, /"__typename":"Video","id":"(\d{6,})"/g, /"id":"(\d{10,})"/g];
  const DUR_RES = [/"playable_duration_in_ms":(\d+)/g, /"length_in_second":([\d.]+)/g];
  const CAP_RES = [/"message":\{"text":"((?:[^"\\]|\\.){1,160})/g, /"title":\{"text":"((?:[^"\\]|\\.){1,160})/g];

  const unjson = s => { try { return JSON.parse('"' + s + '"'); } catch { return null; } };

  // tìm kết quả gần vị trí pos nhất trong cửa sổ văn bản
  function nearest(txt, pos, regs, span) {
    const from = Math.max(0, pos - span), win = txt.slice(from, pos + span);
    let best = null, bestD = Infinity;
    for (const re of regs) {
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(win))) {
        const d = Math.abs(from + m.index - pos);
        if (d < bestD) { bestD = d; best = m[1]; }
      }
      if (best !== null && re === regs[0] && bestD < span / 3) break; // mẫu ưu tiên đã đủ gần
    }
    return best;
  }

  function parse(txt) {
    if (!txt || txt.indexOf("fbcdn") < 0) return [];
    const map = new Map();
    URL_RE.lastIndex = 0;
    let m, n = 0;
    while ((m = URL_RE.exec(txt)) && n++ < 400) {
      const url = unjson(m[2]);
      if (!url || !/^https?:\/\/[^/]*fbcdn\.net\//.test(url)) continue;
      const key = m[1];
      const after = txt.slice(m.index, m.index + 400);
      const hd = /hd/.test(key) || (key === "progressive_url" && /"quality":"HD"/.test(after));
      const pos = m.index;
      const id = nearest(txt, pos, ID_RES, 4000) || url.split("?")[0].split("/").pop();
      const owner = unjson(nearest(txt, pos, OWNER_RES, 8000) || "") || "";
      const ms = nearest(txt, pos, [DUR_RES[0]], 6000);
      const sec = ms ? 0 : nearest(txt, pos, [DUR_RES[1]], 6000);
      const dur = ms ? +ms / 1000 : (sec ? +sec : 0);
      const cap = unjson(nearest(txt, pos, CAP_RES, 6000) || "") || "";
      const it = map.get(id) || { id, owner: "", dur: 0, cap: "", hd: "", sd: "" };
      if (hd && !it.hd) it.hd = url;
      if (!hd && !it.sd) it.sd = url;
      if (!it.owner && owner) it.owner = owner;
      if (!it.dur && dur) it.dur = Math.round(dur);
      if (!it.cap && cap) it.cap = cap.replace(/\s+/g, " ").trim().slice(0, 100);
      map.set(id, it);
    }
    return [...map.values()].filter(x => x.hd || x.sd);
  }

  (typeof window !== "undefined" ? window : self).__pltParseFB = parse;
})();
