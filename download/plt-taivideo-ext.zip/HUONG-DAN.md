# PLT Tải Video – Extension Chrome (v1.0.0, build 20261119-1100)

## Cài đặt (Chrome, Edge, Cốc Cốc)
1. Giải nén file zip ra một thư mục cố định (đừng xoá thư mục sau khi cài).
2. Mở `chrome://extensions` (Edge: `edge://extensions`).
3. Bật **Chế độ dành cho nhà phát triển** (Developer mode) ở góc phải.
4. Bấm **Tải tiện ích đã giải nén** (Load unpacked) → chọn thư mục vừa giải nén.
5. Bấm biểu tượng mảnh ghép → ghim **PLT Tải Video** ra thanh công cụ.

## Cách dùng
1. Mở video Facebook / Douyin / YouTube, **bấm phát vài giây**.
2. Bấm biểu tượng PLT → chọn dòng muốn tải → **Tải về**.
3. Không thấy video: bấm ⟳ để quét lại.

## Mục hiển thị
- **Khuyên dùng – video có tiếng**: tìm thấy trong trang (Facebook HD/SD, thẻ video Douyin). Ưu tiên chọn mục này.
- **Luồng bắt được**: link mạng lúc video phát. Facebook/YouTube thường tách **hình riêng, tiếng riêng**.
- **HLS / DASH**: bấm Copy link, dán vào IDM hoặc VLC để tải.

## Sửa thông tin
- Số Zalo: file `popup.html`, dòng `zalo.me/0900000000`.

## Giới hạn
- YouTube: nhiều video được bảo vệ, không bắt được luồng; nếu bắt được thì hình và tiếng là 2 file riêng.
- Không đưa bản có YouTube lên Chrome Web Store (bị cấm). Phát hành bằng file zip trên web.
